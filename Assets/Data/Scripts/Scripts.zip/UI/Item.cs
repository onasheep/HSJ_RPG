using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Text;
using Newtonsoft.Json;
using System.IO;


[Serializable]
public struct ItemData
{
    public int index;
    public string name;
    public int atk;
    public int def;
    public int value;
    public int price;
    public int type;
    public string imagename;
}
[SerializeField]
public class Item : MonoBehaviour
{
    ItemData data;
    void Start()
    {
 
    }

    public ItemData FromJson(int n)
    {
        List<ItemData> datalist = new List<ItemData>();
        string[] list = File.ReadAllLines(Application.dataPath + "/Data/Json/ItemData.json");
        foreach (string s in list)
        {
            data = JsonUtility.FromJson<ItemData>(s);
            datalist.Add(data);
        }
        Debug.Log(datalist[1].imagename);
        return datalist[n];
    }


    private void OnTriggerStay(Collider other)
    {      
            if (Input.GetKeyDown(KeyCode.G))
            {
                Destroy(this.gameObject);
            }        
    }
}
