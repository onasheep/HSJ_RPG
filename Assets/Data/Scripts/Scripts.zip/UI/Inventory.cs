using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Inventory : MonoBehaviour
{
    public GameObject ItemArea;
    private ItemSlot[] itemslots;
    public Item item;
    ItemData items;
    
    void Start()
    {
        itemslots = ItemArea.GetComponentsInChildren<ItemSlot>();
        items = item.FromJson(0);
        Debug.Log(items.atk);
    }

    void Update()
    {
        
    }

    public void AddItem()
    {
        for (int i = 0; i < itemslots.Length; i++)
        {
            if (itemslots[i] != null)
            {
               
            }
        }
    }
}
