using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;

public class Player : Character
{


    #region �ؽ�Ʈ
    // ���� �ؽ�Ʈ ������Ʈ
    [SerializeField]
    TMPro.TMP_Text LV;
    [SerializeField]
    TMPro.TMP_Text HP;
    [SerializeField]
    TMPro.TMP_Text MP;
    [SerializeField]
    TMPro.TMP_Text EXP;
    [SerializeField]
    TMPro.TMP_Text ATK;
    [SerializeField]
    TMPro.TMP_Text DEF;
    #endregion





    public enum STATE
    {
        NONE, CREATE, PLAY, DEAD
    }
    public STATE mystate = STATE.NONE;
    public LayerMask PickingMask;
    public LayerMask InteractiveMask;
    public GameObject MoveMarker;
    private GameObject obj;

    void Start()
    {
        // �⺻ ���� �޺� �νĿ� ���۳�Ʈ 
    ChangeState(STATE.CREATE);
    }
    // ������� 


    void Update()
    {
        StateProcese();
    }


    #region Picking �̵�/ ���� 
    void Picking()
    {

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hit, 9999.9f, PickingMask))
        {
            // ��Ŭ���� �̵�
            if (Input.GetMouseButtonDown(1))
            {
                DestroyMarker();

                int mask = 1 << NavMesh.GetAreaFromName("Walkable");
                if (NavMesh.CalculatePath(this.transform.position, hit.point, mask, path))
                {
                    base.MoveByNav(path.corners, () => DestroyMarker());
                }
                obj = Instantiate(MoveMarker, hit.point + new Vector3(0.0f, 0.1f, 0.0f), Quaternion.Euler(new Vector3(90.0f, 0.0f, 0.0f)));
            }
            
            // ��Ŭ���� �Ϲݰ���
            else if(Input.GetMouseButtonDown(0))
            {
                // ��� �ڷ�ƾ ���� �� NavMeshPath ��ã�� �ʱ�ȭ 
                StopAllCoroutines();
                myNav.ResetPath();

                DestroyMarker();
                base.RotateWhenAttacking(hit.point);
                myAnim.SetBool("Run", false);
                myAnim.SetTrigger("Attack1");
            }

        }     
        
    }
    #endregion 

    /// <summary>
    /// ���� ������ �������� ����
    /// </summary>
    void StickOnGround()
    {
        if (Physics.Raycast(this.transform.position, Vector3.down, out RaycastHit hit, 1.0f, PickingMask, QueryTriggerInteraction.Collide))
        {
            Mathf.Lerp(this.transform.position.y, hit.point.y, Time.deltaTime);           
        }

    }
    void Dodging()
    {
        myNav.ResetPath();
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hit, 9999.9f, PickingMask))
        {
            base.DodgeToPosition(hit.point);
        }
    }

    #region ��Ŀ ����
    void DestroyMarker()
    {
        Destroy(obj);
    }
    #endregion
    void Interactive()
    {
        
    }


    void ChangeState(STATE s)
    {
        if (mystate == s) return;
        mystate = s;
        switch (mystate)
        {
            case STATE.CREATE:
                ChangeState(STATE.PLAY);
                break;
            case STATE.PLAY:
                myAnim.SetBool("Moveable", true);
                break;
            case STATE.DEAD:
                break;
        }
    }

    void StateProcese()
    {
        switch (mystate)
        {
            case STATE.CREATE:
                break;
            case STATE.PLAY:
                #region NavMeshPath ����� �� 
                for (int i = 0; i < path.corners.Length - 1; i++)
                {
                    Debug.DrawLine(path.corners[i], path.corners[i + 1], Color.red);
                }
                #endregion

                if (myAnim.GetBool("Moveable") & !myAnim.GetBool("IsAttacking"))
                {
                    Picking();
                }

                //if (Input.GetMouseButtonDown(0) & myAnim.GetBool("Moveable") & !myAnim.GetBool("IsAttacking"))
                //{
                //    DestroyMarker();
                //}

                if (Input.GetKeyDown(KeyCode.Space) & myAnim.GetBool("Moveable") & !myAnim.GetBool("IsAttacking"))
                {
                    DestroyMarker();
                    Dodging();
                }

                StickOnGround();
                break;
            case STATE.DEAD:
                break;
        }

    }


}
