using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile : MonoBehaviour
{
    [SerializeField] int TileNumber = 0;

    public void Initialize(int tilenum, Vector3 pos)
    {
        TileNumber = tilenum;
        this.transform.localPosition = pos;
    }
}
