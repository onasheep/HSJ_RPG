using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapManager : MonoBehaviour
{
    [SerializeField] GameObject TileSource = null;
    [SerializeField] Vector2 MapSize = Vector2.zero;
    [SerializeField] List<Tile> Tilelist = new List<Tile>();

    private void Start()
    {
        CreatMap();
    }
    public void CreatMap()
    {
        foreach(Tile scp in Tilelist)
        {
            if(scp != null)
            {
                DestroyImmediate(scp.gameObject);
            }
        }
        Tilelist.Clear();

        this.transform.localPosition = this.transform.position/*new Vector3(-MapSize.x / 2.0f + 0.5f, this.transform.position.y ,MapSize.y / 2.0f - 0.5f)*/;
        for (int y = 0; y < MapSize.y; y++)
        {
            for (int x = 0; x < MapSize.x; x++)
            {
                Tilelist.Add(Instantiate(TileSource, this.transform).GetComponent<Tile>());
                Tilelist[Tilelist.Count - 1].name = $"Tile[{y}][{x}]";
                Tilelist[Tilelist.Count - 1].Initialize(Tilelist.Count - 1, new Vector3(x, 0, -y));
            }
        }
    }
}
